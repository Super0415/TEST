/* ******************************************************************** */
/*                   Software for Elctronic Unit (V1.0)                 */
/*                       Source File SPI2Cortex.c                       */
/*                            By: Wu Xuekui                             */
/*                             2017-11-02                               */
/* ******************************************************************** */

#define   SPI2_GLOBALS
#include "TYPCortex.h"

/* ******************************************************************** */
/*                              SPI2Init ()                             */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
void SPI2Init (void)
{   uiSPI2Status = 0;
    SPI2HardInit();
}
#endif

/* ******************************************************************** */
/*                              SPI2Start ()                            */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
void SPI2Start (void)
{
}
#endif

/* ******************************************************************** */
/*                            SPI2TaskLoop ()                           */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
void SPI2TaskLoop (void)
{   while (1)
    {   (void)OSTimeDly(OS_TICKS_PER_SEC);
    }
}
#endif

/* ******************************************************************** */
/*                          SPI2ReadWrite08u()                          */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
INT08U SPI2ReadWrite08u (INT08U ucData)
{   INT32U uiBit = 8;
    SPI2_CLR_PIN_CS0();
    while (uiBit--)
    {   if ((ucData & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucData <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucData++;
        }
        SPI2_CLR_PIN_SCK();
    }
    SPI2_SET_PIN_CS0();
    return ucData;
}
#endif

/* ******************************************************************** */
/*                          SPI2ReadWrite16u()                          */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
INT16U SPI2ReadWrite16u (INT16U usData)
{   INT32U uiBit = 16;
    SPI2_CLR_PIN_CS0();
    while (uiBit--)
    {   if ((usData & 0x8000) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        usData <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   usData++;
        }
        SPI2_CLR_PIN_SCK();
    }
    SPI2_SET_PIN_CS0();
    return usData;
}
#endif

/* ******************************************************************** */
/*                          SPI2ReadWrite32u()                          */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
INT32U SPI2ReadWrite32u (INT32U uiData)
{   INT32U uiBit = 32;
    SPI2_CLR_PIN_CS0();
    while (uiBit--)
    {   if ((uiData & 0x80000000) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        uiData <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   uiData++;
        }
        SPI2_CLR_PIN_SCK();
    }
    SPI2_SET_PIN_CS0();
    return uiData;
}
#endif

/* ******************************************************************** */
/*                          SPI2ReadEeprom08p()                         */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
INT08U SPI2ReadEeprom08p (INT08U *pData, INT16U usAddr, INT16U usSize)
{   INT32U uiBit;
    INT08U ucCode;
    SPI2_CLR_PIN_CS0();
    ucCode = (INT08U)SPI2_AT25128_READ;
    uiBit  = 8;
    while (uiBit--)
    {   if ((ucCode & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucCode <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucCode++;
        }
        SPI2_CLR_PIN_SCK();
    }
    ucCode = (INT08U)(usAddr >> 8);
    uiBit  = 8;
    while (uiBit--)
    {   if ((ucCode & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucCode <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucCode++;
        }
        SPI2_CLR_PIN_SCK();
    }
    ucCode = (INT08U)usAddr;
    uiBit  = 8;
    while (uiBit--)
    {   if ((ucCode & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucCode <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucCode++;
        }
        SPI2_CLR_PIN_SCK();
    }
    while (usSize--)
    {   ucCode = 0;
        uiBit  = 8;
        while (uiBit--)
        {   if ((ucCode & 0x80) == 0)
            {   SPI2_CLR_PIN_SOUT();
            }   else
            {   SPI2_SET_PIN_SOUT();
            }
            ucCode <<= 1;
            SPI2_SET_PIN_SCK();
            SPI2_DELAY_SHORT();
            if (SPI2_GET_PIN_SIN() != 0)
            {   ucCode++;
            }
            SPI2_CLR_PIN_SCK();
        }
        *pData++ = ucCode;
    }
    SPI2_SET_PIN_CS0();
    return SPI2_TRUE;
}
#endif

/* ******************************************************************** */
/*                          SPI2SendEeprom08p()                         */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
INT08U SPI2SendEeprom08p (INT08U *pData, INT16U usAddr, INT16U usSize)
{   INT32U uiBit, j;
    INT08U ucCode;
    SPI2_CLR_PIN_CS0();
    ucCode = SPI2_AT25128_WREN;
    uiBit  = 8;
    while (uiBit--)
    {   if ((ucCode & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucCode <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucCode++;
        }
        SPI2_CLR_PIN_SCK();
    }
    SPI2_SET_PIN_CS0();
    SPI2_DELAY_SHORT();
    SPI2_DELAY_SHORT();
    SPI2_DELAY_SHORT();
    SPI2_CLR_PIN_CS0();
    ucCode = (INT08U)SPI2_AT25128_WRITE;
    uiBit  = 8;
    while (uiBit--)
    {   if ((ucCode & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucCode <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucCode++;
        }
        SPI2_CLR_PIN_SCK();
    }
    ucCode = (INT08U)(usAddr >> 8);
    uiBit  = 8;
    while (uiBit--)
    {   if ((ucCode & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucCode <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucCode++;
        }
        SPI2_CLR_PIN_SCK();
    }
    ucCode = (INT08U)usAddr;
    uiBit  = 8;
    while (uiBit--)
    {   if ((ucCode & 0x80) == 0)
        {   SPI2_CLR_PIN_SOUT();
        }   else
        {   SPI2_SET_PIN_SOUT();
        }
        ucCode <<= 1;
        SPI2_SET_PIN_SCK();
        SPI2_DELAY_SHORT();
        if (SPI2_GET_PIN_SIN() != 0)
        {   ucCode++;
        }
        SPI2_CLR_PIN_SCK();
    }
    while (usSize--)
    {   ucCode = *pData++;
        uiBit  = 8;
        while (uiBit--)
        {   if ((ucCode & 0x80) == 0)
            {   SPI2_CLR_PIN_SOUT();
            }   else
            {   SPI2_SET_PIN_SOUT();
            }
            ucCode <<= 1;
            SPI2_SET_PIN_SCK();
            SPI2_DELAY_SHORT();
            if (SPI2_GET_PIN_SIN() != 0)
            {   ucCode++;
            }
            SPI2_CLR_PIN_SCK();
        }
    }
    SPI2_SET_PIN_CS0();
    SPI2_DELAY_SHORT();
    SPI2_DELAY_SHORT();
    SPI2_DELAY_SHORT();
    SPI2_CLR_PIN_CS0();
    for (j=0; j<1000; j++)
    {   ucCode = (INT08U)SPI2_AT25128_RDSR;
        uiBit  = 8;
        while (uiBit--)
        {   if ((ucCode & 0x80) == 0)
            {   SPI2_CLR_PIN_SOUT();
            }   else
            {   SPI2_SET_PIN_SOUT();
            }
            ucCode <<= 1;
            SPI2_SET_PIN_SCK();
            SPI2_DELAY_SHORT();
            if (SPI2_GET_PIN_SIN() != 0)
            {   ucCode++;
            }
            SPI2_CLR_PIN_SCK();
        }
        ucCode = 0;
        uiBit  = 8;
        while (uiBit--)
        {   if ((ucCode & 0x80) == 0)
            {   SPI2_CLR_PIN_SOUT();
            }   else
            {   SPI2_SET_PIN_SOUT();
            }
            ucCode <<= 1;
            SPI2_SET_PIN_SCK();
            SPI2_DELAY_SHORT();
            if (SPI2_GET_PIN_SIN() != 0)
            {   ucCode++;
            }
            SPI2_CLR_PIN_SCK();
        }
        if ((ucCode & 0x01) == 0)
        {   SPI2_SET_PIN_CS0();
            return SPI2_TRUE;
        }
    }
    SPI2_SET_PIN_CS0();
    return SPI2_FALSE;
}
#endif

/* ******************************************************************** */
/*                             SPI2HardInit()                           */
/* ******************************************************************** */
#if (SPI2_FUNCTION_ON == 1)
void SPI2HardInit (void)
{   XIOConfigGPIO(SPI2_PT_CS0,  SPI2_BT_CS0,  XIO_PT_GPO_PP_10M, XIO_PT_SET_1);
    XIOConfigGPIO(SPI2_PT_SCK,  SPI2_BT_SCK,  XIO_PT_GPO_PP_10M, XIO_PT_SET_0);
    XIOConfigGPIO(SPI2_PT_SOUT, SPI2_BT_SOUT, XIO_PT_GPO_PP_10M, XIO_PT_SET_0);
    XIOConfigGPIO(SPI2_PT_WP,   SPI2_BT_WP,   XIO_PT_GPO_PP_10M, XIO_PT_SET_1);
    XIOConfigGPIO(SPI2_PT_SIN,  SPI2_BT_SIN,  XIO_PT_GPI_FLOAT,  XIO_PT_SET_0);
    SPI2_SET_PIN_CS0();
    SPI2_CLR_PIN_SCK();
    SPI2_CLR_PIN_SOUT();
    SPI2_SET_PIN_WP();
}
#endif

/* ******************************************************************** */
/*                                The End                               */
/* ******************************************************************** */